using Microsoft.Xna.Framework;
using $safeprojectname$.Shapes;

namespace $safeprojectname$.Collisions
{
    public class CollisionInfo
    {
        public ICollidable Other { get; internal set; }
        public Vector2 PenetrationVector { get; internal set; }
    }
}