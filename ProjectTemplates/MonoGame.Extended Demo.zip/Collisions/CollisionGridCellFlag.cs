namespace $safeprojectname$.Collisions
{
    public enum CollisionGridCellFlag
    {
        Empty,
        Solid,
        Interesting
    }
}