﻿using $safeprojectname$.Shapes;

namespace $safeprojectname$.SceneGraphs
{
    public interface ISceneEntity
    {
        RectangleF GetBoundingRectangle();
    }
}