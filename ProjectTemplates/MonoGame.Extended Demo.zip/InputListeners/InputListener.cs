﻿using Microsoft.Xna.Framework;
using $safeprojectname$.ViewportAdapters;

namespace $safeprojectname$.InputListeners
{
    public abstract class InputListener
    {
        protected InputListener()
        {
        }

        internal ViewportAdapter ViewportAdapter { get; set; }

        internal abstract void Update(GameTime gameTime);
    }
}