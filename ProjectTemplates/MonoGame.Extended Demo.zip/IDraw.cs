﻿using Microsoft.Xna.Framework;

namespace $safeprojectname$
{
    public interface IDraw
    {
        void Draw(GameTime gameTime);
    }
}