﻿using Microsoft.Xna.Framework;

namespace $safeprojectname$
{
    public interface IMovable
    {
        Vector2 Position { get; set; }
    }
}