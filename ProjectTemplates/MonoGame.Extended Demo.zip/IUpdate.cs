﻿using Microsoft.Xna.Framework;

namespace $safeprojectname$
{
    public interface IUpdate
    {
        void Update(GameTime gameTime);
    }
}