﻿using System.Collections.Generic;

namespace $safeprojectname$.Maps.Tiled
{
    public class TiledProperties : Dictionary<string, string>
    {
    }
}