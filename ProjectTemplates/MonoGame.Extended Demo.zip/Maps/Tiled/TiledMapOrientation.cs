﻿namespace $safeprojectname$.Maps.Tiled
{
    public enum TiledMapOrientation
    {
        Orthogonal = 1,
        Isometric = 2,
        Staggered = 3
    }
}
