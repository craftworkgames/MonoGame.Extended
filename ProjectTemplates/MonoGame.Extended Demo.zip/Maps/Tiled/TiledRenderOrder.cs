namespace $safeprojectname$.Maps.Tiled
{
    public enum TiledRenderOrder
    {
        RightDown,
        RightUp,
        LeftDown,
        LeftUp
    }
}