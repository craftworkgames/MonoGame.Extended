﻿namespace $safeprojectname$.Timers
{
    public enum TimerState
    {
        Started,
        Stopped,
        Paused,
        Completed
    }
}
