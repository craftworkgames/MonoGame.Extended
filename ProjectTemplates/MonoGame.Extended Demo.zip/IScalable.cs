using Microsoft.Xna.Framework;

namespace $safeprojectname$
{
    public interface IScalable
    {
        Vector2 Scale { get; set; }
    }
}