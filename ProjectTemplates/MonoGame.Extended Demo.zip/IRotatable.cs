﻿namespace $safeprojectname$
{
    public interface IRotatable
    {
        float Rotation { get; set; }
    }
}